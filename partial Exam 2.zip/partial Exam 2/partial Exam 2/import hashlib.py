import hashlib
import base64

# Step 1: Password hash in hex
password_hex = "200ceb26807d6bf99fd6f4f0d1ca54d4"
password_bytes = bytes.fromhex(password_hex)

# Step 2: MD5 of 'secret'
md5_secret = hashlib.md5(b"secret").digest()

# Step 3: XOR byte-by-byte
xor_bytes = bytes([b1 ^ b2 for b1, b2 in zip(password_bytes, md5_secret)])

# Step 4: Base64 encode
encrypted_cookie = base64.b64encode(xor_bytes).decode()

print(encrypted_cookie)
