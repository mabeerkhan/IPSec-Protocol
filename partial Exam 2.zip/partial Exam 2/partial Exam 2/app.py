from flask import Flask, request, make_response
import hashlib
import base64

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def challenge():
    completed = []

    # Keep track of messages
    log_messages = []

    # Requirement 1: query parameter
    if request.args.get("hello") == "thatwaseasy":
        completed.append(1)
        log_messages.append("[+] Task 1 completed")

    # Requirement 2: POST param username
    username = request.form.get("username")
    if username == "administrator":
        completed.append(2)
        log_messages.append("[+] Task 2 completed")

    # Requirement 3: password = md5(username)
    password = request.form.get("password")
    if username == "administrator":
        expected_md5 = hashlib.md5(username.encode()).hexdigest()
        if password == expected_md5:
            completed.append(3)
            log_messages.append("[+] Task 3 completed")

    # Requirement 4: header check
    if request.headers.get("X-Solve-Final-Requirement") == "sqlmap":
        completed.append(4)
        log_messages.append("[+] Task 4 completed")

    # Requirement 5: cookie check
    encrypted_cookie = request.cookies.get("encrypted")
    if password:
        secret_md5 = hashlib.md5("secret".encode()).digest()
        xor_result = bytes(a ^ b for a, b in zip(bytes.fromhex(password), secret_md5))
        expected_cookie = base64.b64encode(xor_result).decode()
        if encrypted_cookie == expected_cookie:
            completed.append(5)
            log_messages.append("[+] Task 5 completed")

    # Print logs to terminal
    if log_messages:
        print("\n--- New Request ---")
        for msg in log_messages:
            print(msg)
    else:
        print("\n--- New Request: No tasks completed ---")

    # HTML Response
    html = """<!DOCTYPE html>
<html>
<head>
    <title>Web Security Challenge #1</title>
</head>
<body>
    <h2>Web Security Challenge #1</h2>
    <p>Your objective is to perform the correct HTTP requests given the requirements stated below</p>
    <div id=target style="height:100px"></div>
    <ul id=list>
        <li style="color:{0}"><b>Requirement 1: Add a query parameter <tt>?hello=thatwaseasy</tt></b></li>
        <li style="color:{1}"><b>Requirement 2: POST parameter <tt>username=administrator</tt></b></li>
        <li style="color:{2}"><b>Requirement 3: POST parameter <tt>password=md5(username)</tt></b></li>
        <li style="color:{3}"><b>Requirement 4: Header <tt>X-Solve-Final-Requirement: sqlmap</tt></b></li>
        <li style="color:{4}"><b>Requirement 5: Cookie <tt>encrypted</tt> = base64(password XOR md5('secret'))</b></li>
        {5}
    </ul>
</body>
</html>"""

    colors = ["green" if i + 1 in completed else "red" for i in range(5)]
    flag = ""
    if len(completed) == 5:
        flag = """<li style="color:green"><b>Congratulation! the flag is <tt>ICTSEC2025{0efd20b5f343053ccb50ec5cdc7fb2709fefef7767c51bff8a7b319eedd78c34}</tt></b></li>"""

    response = make_response(html.format(*colors, flag))
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)